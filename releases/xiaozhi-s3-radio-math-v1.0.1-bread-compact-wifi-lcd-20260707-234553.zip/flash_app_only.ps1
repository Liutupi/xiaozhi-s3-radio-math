﻿param(
    [string]$Port = "COM4"
)

$ErrorActionPreference = "Stop"
python -m esptool --chip esp32s3 -p $Port -b 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 16MB --flash_freq 80m 0x100000 firmware\xiaozhi.bin
