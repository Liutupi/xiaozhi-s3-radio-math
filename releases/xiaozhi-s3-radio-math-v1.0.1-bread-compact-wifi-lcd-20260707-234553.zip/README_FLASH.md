﻿# xiaozhi-s3-radio-math v1.0.1

## Contents

- Xiaozhi assistant
- Internet radio
- Settings screen
- Animated minimal face
- MusicPlayer.PlayUrl for direct MP3 URLs returned by music MCP services

## Flash

Use app-only flashing to preserve NVS/Wi-Fi settings.

    .\flash_app_only.ps1 -Port COM4

If the device is not on COM4, replace it with the actual serial port.

## Firmware Info

- Board: bread-compact-wifi-lcd
- Chip: esp32s3
- Flash: 16MB
- App offset: 0x100000
- SHA256: 7e58272bbf5f504c7c5602bfceb5d0666349b2096f9318ad52e749d28a8801ea
