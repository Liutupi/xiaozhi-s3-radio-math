﻿# xiaozhi-s3-radio-math v1.0.0

## Contents

- Xiaozhi assistant
- Internet radio

## Flash

Use app-only flashing to preserve NVS/Wi-Fi settings.

`powershell
.\flash_app_only.ps1 -Port COM4
`

If the device is not on COM4, replace it with the actual serial port.

## Firmware Info

- Board: bread-compact-wifi-lcd
- Chip: esp32s3
- Flash: 16MB
- App offset: 0x100000
- SHA256: ce36eff695443cde5b85f809e683e0808d0a398939e253904db38422cb0a737d
